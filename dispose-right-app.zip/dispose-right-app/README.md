# Dispose Right — E-Cigarette Waste Guidance App

A React + Vite prototype of the 5-layer IT-enabled e-waste management framework
proposed in Chapter 5 of the thesis "E-Cigarette Disposal Behavior Among Urban
Youth in Bangladesh". This app implements Layers 1–3:

- **Layer 1 — Mobile Disposal App**: step-by-step guidance with a live
  "disposal confidence" ring (a nod to Self-Efficacy, β = 0.289, the strongest
  predictor in the model).
- **Layer 2 — QR-Code Guidance**: the home screen's QR tile simulates a
  real product scan jumping straight to item-specific instructions.
- **Layer 3 — GIS Collection Finder**: a real, interactive Google Map
  (no API key required) with selectable Dhaka disposal points, live distance
  calculation, and one-tap directions.

Layers 4–5 (Retailer Take-Back Registry, Municipal Dashboard) are shown as a
concept summary on the System screen.

## Run locally

```bash
npm install
npm run dev
```

Open the printed localhost URL.

## Build for deployment

```bash
npm run build
```

This outputs a static site to `dist/` — upload that folder to any static host
(Vercel, Netlify, Cloudflare Pages, GitHub Pages). No environment variables or
API keys are required; the map uses Google's key-less embed endpoint.

### Optional: upgrade the map

The Finder screen (`src/components/Finder.jsx`) currently uses a key-less
Google Maps iframe embed (`google.com/maps?q=...&output=embed`), which works
out of the box with no billing account. If you want live markers, custom
styling, or clustering, swap it for `@react-google-maps/api` and supply your
own `VITE_GOOGLE_MAPS_API_KEY`.

## Editing content

- Disposal locations & coordinates: `src/data/locations.js`
- Step-by-step guidance per item type: `src/data/guides.js`
- Design tokens (colors, type, spacing): `src/index.css` (`:root` block at top)
