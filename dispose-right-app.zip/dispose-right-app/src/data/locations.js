// Reference point used to compute "distance from you" (central Dhaka)
export const YOU = { lat: 23.7580, lng: 90.3897, label: "Farmgate, Dhaka" };

export const LOCATIONS = [
  {
    id: "diu",
    name: "DIU Campus Collection Node",
    type: "University drop-off",
    layer: "Layer 3 · GIS-mapped",
    lat: 23.7461,
    lng: 90.3742,
    address: "Daffodil International University, Dhanmondi, Dhaka",
    open: "Open now · 9:00 AM – 8:00 PM",
  },
  {
    id: "banani",
    name: "Banani Tech Hub Bin",
    type: "Retailer take-back point",
    layer: "Layer 4 · Retailer registry",
    lat: 23.7936,
    lng: 90.4043,
    address: "Road 11, Banani, Dhaka",
    open: "Open now · 10:00 AM – 9:00 PM",
  },
  {
    id: "gulshan",
    name: "Gulshan Municipal Facility",
    type: "Formal e-waste facility",
    layer: "Layer 5 · Govt monitored",
    lat: 23.7808,
    lng: 90.4179,
    address: "Gulshan Circle 1, Dhaka",
    open: "Open now · 8:00 AM – 6:00 PM",
  },
  {
    id: "dhanmondi",
    name: "Dhanmondi Retail Point",
    type: "Retailer take-back point",
    layer: "Layer 4 · Retailer registry",
    lat: 23.7461,
    lng: 90.3742,
    address: "Road 27, Dhanmondi, Dhaka",
    open: "Open now · 11:00 AM – 9:00 PM",
  },
  {
    id: "uttara",
    name: "Uttara Collection Node",
    type: "Community drop-off",
    layer: "Layer 3 · GIS-mapped",
    lat: 23.8759,
    lng: 90.3795,
    address: "Sector 7, Uttara, Dhaka",
    open: "Open now · 9:00 AM – 7:00 PM",
  },
];

// Haversine distance in km
export function distanceKm(a, b) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function locationsSortedByDistance() {
  return [...LOCATIONS]
    .map((loc) => ({ ...loc, distance: distanceKm(YOU, loc) }))
    .sort((a, b) => a.distance - b.distance);
}
