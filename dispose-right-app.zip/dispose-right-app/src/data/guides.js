export const GUIDES = {
  pod: {
    title: "Vape Pod",
    hazard: "Non-biodegradable plastic + residual nicotine",
    steps: [
      "Do not throw in household trash — plastic persists in landfill for centuries and nicotine leaches into soil.",
      "Empty any remaining e-liquid into a sealed container first.",
      "Wipe the pod dry, then place it in a labelled disposal bag.",
      "Drop it at a collection point — never a public street bin.",
    ],
  },
  battery: {
    title: "Lithium-Ion Battery",
    hazard: "Thermal-runaway fire risk in waste streams",
    steps: [
      "Never bin loose — batteries cause fires in waste trucks and recycling plants.",
      "Tape both terminals with clear tape to prevent short-circuiting.",
      "Store in a cool, dry pouch until drop-off — avoid direct sunlight or heat.",
      "Take only to a certified e-waste or battery collection point.",
    ],
  },
  liquid: {
    title: "E-Liquid Bottle",
    hazard: "Toxic to aquatic organisms and groundwater",
    steps: [
      "Never pour leftover liquid down a drain or into soil — it leaches into groundwater systems.",
      "Keep the cap tightly sealed to avoid leaks in transit.",
      "Wrap the bottle in a bag if any residue is visible outside.",
      "Hand it to a formal facility, not a public bin.",
    ],
  },
  device: {
    title: "Full Device",
    hazard: "Mixed plastics, chemicals, and battery",
    steps: [
      "A full device mixes plastics, chemicals, and a battery — treat it as hazardous, not general waste.",
      "Power it off completely before transport.",
      "Keep it in original packaging if you still have it.",
      "Bring the whole unit to a collection point — don't disassemble it yourself.",
    ],
  },
};
