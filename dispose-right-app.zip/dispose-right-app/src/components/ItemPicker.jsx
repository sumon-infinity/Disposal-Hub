const ITEMS = [
  {
    key: 'pod',
    label: 'Vape Pod',
    sub: 'Plastic + nicotine',
    icon: (
      <svg className="item-ic" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="1.6">
        <rect x="7" y="4" width="10" height="16" rx="3" />
        <path d="M9 4 L9 2 M15 4 L15 2" />
      </svg>
    ),
  },
  {
    key: 'battery',
    label: 'Battery',
    sub: 'Lithium-ion',
    icon: (
      <svg className="item-ic" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="1.6">
        <rect x="6" y="7" width="12" height="14" rx="2" />
        <rect x="9" y="4" width="6" height="3" rx="1" />
        <path d="M9 13 L15 13 M12 10 L12 16" />
      </svg>
    ),
  },
  {
    key: 'liquid',
    label: 'E-Liquid Bottle',
    sub: 'Nicotine residue',
    icon: (
      <svg className="item-ic" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="1.6">
        <path d="M10 3 H14 V7 L17 13 V19 A2 2 0 0 1 15 21 H9 A2 2 0 0 1 7 19 V13 L10 7 Z" />
      </svg>
    ),
  },
  {
    key: 'device',
    label: 'Full Device',
    sub: 'Mixed materials',
    icon: (
      <svg className="item-ic" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="1.6">
        <rect x="8" y="3" width="8" height="18" rx="3" />
        <circle cx="12" cy="8" r="1.3" fill="#0f3d3e" stroke="none" />
      </svg>
    ),
  },
];

export default function ItemPicker({ onSelect }) {
  return (
    <div>
      <div className="section-title">What did you scan?</div>
      <p className="section-sub">We'll give you the exact disposal steps for this item.</p>
      <div className="item-grid">
        {ITEMS.map((it) => (
          <div key={it.key} className="item-card" onClick={() => onSelect(it.key)}>
            {it.icon}
            <span>{it.label}</span>
            <small>{it.sub}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
