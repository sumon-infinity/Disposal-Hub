import { useState, useMemo } from 'react';
import { locationsSortedByDistance } from '../data/locations.js';

export default function Finder({ onMarkDisposed }) {
  const locations = useMemo(() => locationsSortedByDistance(), []);
  const [selectedId, setSelectedId] = useState(locations[0]?.id);
  const selected = locations.find((l) => l.id === selectedId) ?? locations[0];

  const mapSrc = `https://www.google.com/maps?q=${selected.lat},${selected.lng}&z=15&output=embed`;
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${selected.lat},${selected.lng}`;

  return (
    <div>
      <div className="section-title">Nearest collection points</div>
      <p className="section-sub">
        Layer 3 · GIS Collection Finder — solves the Facility Support gap by making
        disposal bins discoverable.
      </p>

      <div className="map-frame">
        <div className="map-tag">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="2.2">
            <path d="M12 21 C12 21 5 14 5 9 A7 7 0 0 1 19 9 C19 14 12 21 12 21 Z" />
            <circle cx="12" cy="9" r="2.4" />
          </svg>
          {selected.name}
        </div>
        <iframe
          title="disposal-map"
          src={mapSrc}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      </div>

      <div className="loc-list">
        {locations.map((loc) => (
          <div
            key={loc.id}
            className={`loc-card ${loc.id === selectedId ? 'selected' : ''}`}
            onClick={() => setSelectedId(loc.id)}
          >
            <div className="loc-top">
              <div>
                <div className="loc-name">{loc.name}</div>
                <div className="loc-type">{loc.address}</div>
              </div>
              <div className="loc-dist">{loc.distance.toFixed(1)} km</div>
            </div>
            <div className="loc-meta-row">
              <span className="loc-layer-tag">{loc.layer}</span>
              <span>{loc.open}</span>
            </div>
            {loc.id === selectedId && (
              <a
                className="directions-link"
                href={directionsUrl}
                target="_blank"
                rel="noreferrer"
                onClick={(e) => e.stopPropagation()}
              >
                Get directions →
              </a>
            )}
          </div>
        ))}
      </div>

      <button className="btn btn-primary btn-block" style={{ marginTop: 18 }} onClick={onMarkDisposed}>
        Mark as disposed ✓
      </button>
    </div>
  );
}
