const TABS = [
  {
    key: 'home',
    label: 'Home',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M4 11 L12 4 L20 11 V20 H4 Z" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    key: 'finder',
    label: 'Finder',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="11" cy="11" r="6" />
        <path d="M20 20 L15.5 15.5" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    key: 'system',
    label: 'System',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M4 19 L4 13 M11 19 L11 8 M18 19 L18 4" strokeLinecap="round" />
      </svg>
    ),
  },
];

export default function AppShell({ view, onNavigate, onBack, showBack, children }) {
  return (
    <div className="app-shell">
      <div className="topbar">
        {showBack ? (
          <button className="back-btn" onClick={onBack} aria-label="Back">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0f3d3e" strokeWidth="2">
              <path d="M15 18 L9 12 L15 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        ) : (
          <div className="brand-mark">
            <svg viewBox="0 0 24 24" fill="none">
              <path d="M12 2 L12 10 M8 6 L16 6" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
              <rect x="8" y="10" width="8" height="11" rx="3" stroke="#fff" strokeWidth="2" />
            </svg>
          </div>
        )}
        <div className="brand-text">
          <div className="name">Dispose Right</div>
          <div className="tag">Layer 1–3 · Enhanced SCT Prototype</div>
        </div>
      </div>

      <div className="view">{children}</div>

      <div className="tabbar">
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`tab ${view === t.key ? 'on' : ''}`}
            onClick={() => onNavigate(t.key)}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}
