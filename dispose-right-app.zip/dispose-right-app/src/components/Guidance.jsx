import { useState } from 'react';
import ProgressRing from './ProgressRing.jsx';
import { GUIDES } from '../data/guides.js';

export default function Guidance({ itemKey, onFindDropoff }) {
  const guide = GUIDES[itemKey];
  const [done, setDone] = useState(() => new Set());

  if (!guide) return null;

  const toggleStep = (i) => {
    setDone((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const percent = Math.round((done.size / guide.steps.length) * 100);

  return (
    <div>
      <div className="hazard-tag">⚠ {guide.hazard}</div>
      <h2 className="section-title">{guide.title} — Guidance</h2>
      <p className="section-sub">Tap each step as you complete it.</p>

      <div className="ring-wrap">
        <ProgressRing percent={percent} />
        <div className="ring-copy">
          <strong>Disposal confidence</strong>
          <small>
            Builds as you complete each step — this mirrors Self-Efficacy, the strongest
            behavioral predictor in the Enhanced SCT model (β = 0.289).
          </small>
        </div>
      </div>

      <div>
        {guide.steps.map((s, i) => (
          <div
            key={i}
            className={`step ${done.has(i) ? 'done' : ''}`}
            onClick={() => toggleStep(i)}
          >
            <div className="step-num">{done.has(i) ? '✓' : i + 1}</div>
            <p>{s}</p>
          </div>
        ))}
      </div>

      <button className="btn btn-amber btn-block" style={{ marginTop: 18 }} onClick={onFindDropoff}>
        Find nearest drop-off point →
      </button>
    </div>
  );
}
