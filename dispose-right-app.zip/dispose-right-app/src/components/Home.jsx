export default function Home({ onScan }) {
  return (
    <div>
      <div className="hero-stat">
        <span className="eyebrow">Bangladesh · Urban Youth Survey</span>
        <div className="num">70.7%</div>
        <p className="cap">
          of e-cigarette users dispose devices improperly — in household trash or public bins.
          This app turns hazard awareness into confident action.
        </p>
      </div>

      <div className="section-title">What are you disposing today?</div>
      <p className="section-sub">Scan the product's QR code, or choose it manually below.</p>

      <div className="qr-tile" onClick={onScan}>
        <div className="qr-box" />
        <div className="qr-copy">
          <strong>Tap to simulate a QR scan</strong>
          <small>On a real product, this triggers automatically — that's Layer 2 of the framework.</small>
        </div>
      </div>

      <div className="divider-word">or choose manually</div>

      <button className="btn btn-ghost btn-block" onClick={onScan}>
        Browse item types
      </button>
    </div>
  );
}
