const LAYERS = [
  { tag: 'L1', desc: 'Mobile Disposal App — user level, you are here', on: true },
  { tag: 'L2', desc: 'QR-Code Guidance — triggered your step-by-step flow', on: true },
  { tag: 'L3', desc: 'GIS Collection Finder — found your nearest drop-off', on: true },
  { tag: 'L4', desc: 'Retailer Take-Back Registry — commercial-level infrastructure', on: false },
  { tag: 'L5', desc: 'Municipal Monitoring Dashboard — government policy layer', on: false },
];

export default function SystemView({ completed, onRestart }) {
  return (
    <div>
      {completed && (
        <div className="confetti-badge">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#e8941b" strokeWidth="2.2">
            <path d="M20 6 L9 17 L4 12" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      )}
      <div className="section-title">{completed ? 'Nice work!' : 'The full system'}</div>
      <p className="section-sub">
        {completed
          ? 'You just completed one responsible disposal. Here is how this app fits into the proposed 5-layer framework:'
          : 'This prototype demonstrates Layers 1–3. Layers 4–5 are institutional, built on top of the same data.'}
      </p>

      {LAYERS.map((l) => (
        <div key={l.tag} className={`layer-row ${l.on ? 'on' : ''}`}>
          <div className="layer-tag">{l.tag}</div>
          <span>{l.desc}</span>
        </div>
      ))}

      {completed && (
        <button className="btn btn-ghost btn-block" style={{ marginTop: 16 }} onClick={onRestart}>
          Start over
        </button>
      )}
    </div>
  );
}
