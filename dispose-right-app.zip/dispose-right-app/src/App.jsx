import { useState } from 'react';
import AppShell from './components/AppShell.jsx';
import Home from './components/Home.jsx';
import ItemPicker from './components/ItemPicker.jsx';
import Guidance from './components/Guidance.jsx';
import Finder from './components/Finder.jsx';
import SystemView from './components/SystemView.jsx';

// Screens: home -> items -> guidance -> finder -> system
export default function App() {
  const [screen, setScreen] = useState('home');
  const [itemKey, setItemKey] = useState(null);
  const [completed, setCompleted] = useState(false);

  const activeTab = screen === 'items' || screen === 'guidance' ? 'home' : screen;

  const goHome = () => {
    setScreen('home');
  };

  const navigate = (tab) => {
    if (tab === 'finder') return setScreen('finder');
    if (tab === 'system') return setScreen('system');
    return goHome();
  };

  const handleBack = () => {
    if (screen === 'items') return setScreen('home');
    if (screen === 'guidance') return setScreen('items');
    return goHome();
  };

  return (
    <>
      <AppShell
        view={activeTab}
        onNavigate={navigate}
        onBack={handleBack}
        showBack={screen === 'items' || screen === 'guidance'}
      >
        {screen === 'home' && <Home onScan={() => setScreen('items')} />}
        {screen === 'items' && (
          <ItemPicker
            onSelect={(key) => {
              setItemKey(key);
              setScreen('guidance');
            }}
          />
        )}
        {screen === 'guidance' && (
          <Guidance itemKey={itemKey} onFindDropoff={() => setScreen('finder')} />
        )}
        {screen === 'finder' && (
          <Finder
            onMarkDisposed={() => {
              setCompleted(true);
              setScreen('system');
            }}
          />
        )}
        {screen === 'system' && (
          <SystemView
            completed={completed}
            onRestart={() => {
              setCompleted(false);
              setItemKey(null);
              setScreen('home');
            }}
          />
        )}
      </AppShell>
      <p className="page-foot">
        <b>E-Cigarette Disposal Behavior Among Urban Youth in Bangladesh</b> — An Enhanced
        Social Cognitive Theory Framework for IT-Enabled E-Waste Management. This prototype
        demonstrates Layers 1–3 of the proposed 5-layer system.
      </p>
    </>
  );
}
